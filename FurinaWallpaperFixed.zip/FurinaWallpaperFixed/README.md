# Furina Live Wallpaper

Custom Android live wallpaper with audio support.

## How to Build

1. Download and install **Android Studio** (free): https://developer.android.com/studio
2. Open Android Studio → **Open an existing project** → select this folder
3. Wait for Gradle to sync (first time takes a few minutes)
4. Go to **Build → Build Bundle(s) / APK(s) → Build APK(s)**
5. APK will be at: `app/build/outputs/apk/debug/app-debug.apk`
6. Transfer APK to your phone and install it (enable Unknown Sources)

## How to Set as Wallpaper

1. Long press home screen → **Wallpapers** → **Live Wallpapers**
2. Find **"Furina Live Wallpaper"** and select it
3. Tap **Set Wallpaper**

## Features
- Plays your video on loop with full audio
- Auto-pauses when you open another app (saves battery + RAM)
- Resumes when you return to home screen
